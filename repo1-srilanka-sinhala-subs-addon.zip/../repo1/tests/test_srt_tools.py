#!/usr/bin/env python3
"""test_srt_tools.py — proves the 5 audit bug fixes. Run: python3 -m pytest tests/ -v
Fixtures are REAL site archives (downloaded 2026-11-20): piratelk nested zip and
zoom.lk flat zip; plus synthetic regressions for each bug."""
import io
import sys
import zipfile

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent.parent / "scripts"))
import srt_tools as st  # noqa: E402

PIRATELK_ZIP = str(__import__("pathlib").Path(__file__).parent / "fixtures" / "piratelk-dark-knight.zip")    # real: nested folder + UTF-16LE variant + ad txt
ZOOMLK_ZIP = str(__import__("pathlib").Path(__file__).parent / "fixtures" / "zoomlk-elumale.zip")      # real: flat "Elumale (2025) Kannada HQ HDRip.srt"


def _nested_zip() -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("The Dark Knight (2008) - Piratelk.com/", "")
        z.writestr("The Dark Knight (2008) - Piratelk.com/PirateLk.txt", "ad")
        z.writestr("The Dark Knight (2008) - Piratelk.com/The Dark Knight (2008) 480p BRRip x264 AAC-ChameE.srt", "1\n00:00:01,000 --> 00:00:02,000\nආයෝ\n")
        z.writestr("macosxjunk/._nested.srt", "junk")
        z.writestr("../evil.srt", "evil")
    return buf.getvalue()


def test_bug1_nested_zip_any_depth():
    """Bug 1: srt inside a subfolder must be found (was skipped by '/' check)."""
    b, ext = st.extract_archive(_nested_zip())
    assert ext == "srt"
    assert "ආයෝ" in st.decode(b)
    # real piratelk archive: nested folder path
    real = open(PIRATELK_ZIP, "rb").read()
    rb, rext = st.extract_archive(real)
    assert rext == "srt" and st.parse(st.decode(rb)) != []
    # real zoom.lk archive: flat entry
    zb, zext = st.extract_archive(open(ZOOMLK_ZIP, "rb").read())
    assert zext == "srt" and st.parse(st.decode(zb)) != []


def test_bug1_traversal_and_macosx_rejected():
    names = ["__MACOSX/x.srt", "._dot.srt", "../evil.srt", "/abs.srt", "movie.srt"]
    pick = st.pick_zip_entry(names)
    assert pick is not None and pick[0] == "movie.srt"
    # __MACOSX inside a folder is also skipped
    assert st.pick_zip_entry(["__MACOSX/dir/a.srt", "b.srt"])[0] == "b.srt"


def test_bug2_watermark_edges_only():
    cues = st.parse("1\n00:00:01,000 --> 00:00:02,000\nCredit card?\n\n2\n00:00:03,000 --> 00:00:04,000\n"
                    "Some normal dialogue here.\n\n3\n00:00:05,000 --> 00:00:06,000\nwww.zoom.lk sync by Kasun\n\n"
                    "4\n00:00:07,000 --> 00:00:08,000\nMiddle of movie line.\n")
    kept = st.strip_watermarks(cues)
    # 'Credit card?' must survive (it's dialogue, not a credit line)
    assert any("Credit card" in c["text"] for c in kept)
    # explicit zoom.lk watermark is stripped even mid-file
    assert not any("zoom.lk" in c["text"] for c in kept)
    # head credit
    head = st.parse("1\n00:00:01,000 --> 00:00:02,000\nSubtitles by John\n\n2\n00:00:03,000 --> 00:00:04,000\nReal line.\n")
    assert len(st.strip_watermarks(head)) == 1


def test_bug3_token_match_lowercase_and_group():
    assert st.token_match("INCEPTION.1080P.BluRay.X264-NTb", "inception.1080p.bluray.x264-ntb") > 0.9
    assert st.token_match("Movie.2026.1080p.WEBRip.x264-FLUX", "movie.2026.1080p.webrip.x264-avc") > 0.5  # same tokens, group differs
    assert st.token_match("Movie.2026.1080p.WEBRip.x264-FLUX", "movie.2026.1080p.webrip.x264-flux") == st.token_match("movie.2026.1080p.webrip.x264-flux", "Movie.2026.1080p.WEBRip.x264-FLUX")
    # group bonus applies only after the FINAL hyphen
    s = st.token_match("A.2020.1080p.x264-YTS", "A.2020.1080p.x264-YTS")
    assert s > 0.9
    assert st.token_match("", "whatever") == 0.0
    # year mismatch halves the score
    hi = st.token_match("The Dark Knight 2008 480p ChameE", "The Dark Knight 2008 480p ChameE")
    lo = st.token_match("The Dark Knight 2007 480p ChameE", "The Dark Knight 2008 480p ChameE")
    assert hi > lo


def test_bug4_batch_translate_validation():
    calls = []
    def bad(texts, ctx):        # wrong count once, then correct
        calls.append(1)
        if len(calls) == 1:
            return texts[:-1]
        return [f"si:{t}" for t in texts]
    cues = st.parse("\n\n".join(f"{i+1}\n00:00:0{i},100 --> 00:00:0{i},900\nLine {i} here." for i in range(6)))
    out = st.translate_cues(cues, bad, {"title": "Test"})
    assert len(out) == 6 and all(c["text"].startswith("si:") for c in out)
    assert all(c["start"] == o["start"] and c["end"] == o["end"] for c, o in zip(out, cues))  # timestamps verbatim


def test_bug5_timestamp_repair():
    cues = [
        {"start": 2000, "end": 1000, "text": "reversed"},           # end <= start
        {"start": 3000, "end": 3100, "text": "too short"},           # < 500 ms
        {"start": 3300, "end": 9000, "text": "small overlap"},       # starts before prev end
        {"start": 15000, "end": 16000, "text": "clean"},
    ]
    fixed = st.repair_cues(cues)
    assert fixed[0]["end"] - fixed[0]["start"] == 500               # reversed clamped
    assert fixed[1]["end"] - fixed[1]["start"] >= 500               # min duration
    assert fixed[2]["start"] >= fixed[1]["end"]                     # overlap nudged
    assert fixed[3]["start"] == 15000


def test_parse_emit_roundtrip():
    cues = st.parse("1\n00:00:01,000 --> 00:00:02,500\nHello\nworld\n\n2\n00:01:00,000 --> 00:01:02,000\nBye\n")
    assert len(cues) == 2 and cues[0]["text"] == "Hello\nworld"
    out = st.emit(cues)
    assert "00:00:01,000 --> 00:00:02,500" in out and "Bye" in out
    assert st.parse(out)[0]["start"] == 1000


def test_language_normalization():
    assert st.to_sin("si") == "sin" and st.to_sin("sin") == "sin"
    assert st.to_sin("SI") == "sin" and st.to_sin("sinh") == "sin"
    assert st.to_sin("eng") == "eng"


def test_wrap_sinhala():
    long_line = "මෙය ඉතා දිග සිංහල එක්සතැනක ඇති දිග පේළියක් වන අතර එය එසැසැස්මට වඩා දිගු ය"
    w = st.wrap_si(long_line, width=40)
    assert all(len(l) <= 45 for l in w.split("\n"))
    assert " " in w


if __name__ == "__main__":
    import subprocess
    raise SystemExit(subprocess.call([sys.executable, "-m", "pytest", __file__, "-v"]))
