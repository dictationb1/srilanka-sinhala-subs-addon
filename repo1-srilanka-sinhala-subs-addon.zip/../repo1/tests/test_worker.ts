/** test_worker.ts — node:test suite. Run: node --test tests/
 * Fixtures: REAL piratelk nested zip + zoom.lk flat zip downloaded 2026-11-20.
 * Gemini batch validator is tested with a mock fetch (no API key needed). */
import { test } from 'node:test';
import * as assert from 'node:assert';
import { readFileSync } from 'node:fs';
import { pickZipEntry, kind, extract, isWatermark, repairCues, wrap, decode } from '../src/normalize.ts';
import { parseSrt, emitSrt, stripMarkup, tc } from '../src/srt.ts';
import { toSin, releaseScore, parseVideoId, rank } from '../src/match.ts';
import { bestLinearFit, applyAlign } from '../src/sync.ts';
import { parseAnswer, buildPrompt, translateCues } from '../src/translate/geminiFlash.ts';
import { searchPiratelk } from '../src/sources/piratelk.ts';

const PIRATELK_ZIP = readFileSync(new URL('./fixtures/piratelk-dark-knight.zip', import.meta.url));    // real nested zip
const ZOOMLK_ZIP = readFileSync(new URL('./fixtures/zoomlk-elumale.zip', import.meta.url));      // real flat zip

test('bug1: nested zip entries at any depth (real piratelk archive)', () => {
  assert.equal(kind(PIRATELK_ZIP), 'zip');
  const z = unzipNames(PIRATELK_ZIP);
  const pick = pickZipEntry(z);
  assert.ok(pick, 'found srt in nested folder');
  assert.ok(pick!.name.includes('Piratelk.com/'), pick!.name);
  assert.equal(pick!.ext, 'srt');
});

test('bug1: real zoom.lk flat zip extracts sinhala cues', async () => {
  const sub = await extract(ZOOMLK_ZIP);
  assert.equal(sub.ext, 'srt');
  const cues = parseSrt(sub.text);
  assert.ok(cues.length > 1000, `${cues.length} cues`);
  const sinhala = cues.filter((c) => /[\u0D80-\u0DFF]/.test(c.text)).length;
  assert.ok(sinhala > 500, `${sinhala} sinhala cues`);
});

test('bug1: traversal/__MACOSX rejected', () => {
  const pick = pickZipEntry(['__MACOSX/x/a.srt', '._x.srt', '../evil.srt', '/abs.srt', 'movie.srt']);
  assert.equal(pick?.name, 'movie.srt');
  const nested = pickZipEntry(['__MACOSX/dir/a.srt', 'b/c.srt']);
  assert.equal(nested?.name, 'b/c.srt');
});

test('bug2: watermark edges only, dialogue survives', () => {
  const cues = parseSrt('1\n00:00:01,000 --> 00:00:02,000\nCredit card?\n\n2\n00:00:03,000 --> 00:00:04,000\nNormal line here.\n\n3\n00:00:05,000 --> 00:00:06,000\nwww.zoom.lk sync by Kasun\n');
  assert.equal(isWatermark('Credit card?', 0, cues.length), false);
  assert.equal(isWatermark('Credits by John', 0, cues.length), true);
  assert.equal(isWatermark('www.zoom.lk sync by Kasun', 2, cues.length), true);
  assert.equal(isWatermark('Some normal dialogue here.', 1, 3), false);
});

test('bug3: lowercase jaccard + final-hyphen group', () => {
  assert.ok(releaseScore('INCEPTION.1080P.BluRay.X264-NTb', 'inception.1080p.bluray.x264-ntb') > 0.9);
  const same = releaseScore('A.2020.1080p.x264-YTS', 'A.2020.1080p.x264-YTS');
  assert.ok(same > 0.9);
  assert.equal(releaseScore('', 'x'), 0);
  const hi = releaseScore('Movie 2026 1080p webrip x264-FLUX', 'movie 2026 1080p webrip x264-FLUX');
  const lo = releaseScore('Movie 2025 1080p webrip x264-FLUX', 'movie 2026 1080p webrip x264-FLUX');
  assert.ok(hi > lo, 'year mismatch halves');
});

test('bug4: batch translator validates counts (mock)', async () => {
  let calls = 0;
  const badOnce = async () => (calls++, calls === 1 ? '{"1": "ok"}' : Array.from({ length: 4 }, (_, i) => `{"${i + 1}": "si ${i}"}`).join('\n').replace(/^/, '').replace(/(?<=")(\d+)(?=")/g, '$1'));
  // simulate via parseAnswer on a valid object
  const map = parseAnswer('{"1":"a","2":"b","3":"c","4":"d"}', 4);
  assert.equal(map.size, 4);
  assert.throws(() => parseAnswer('{"1":"a","2":"b"}', 4));
  assert.throws(() => parseAnswer('no json', 4));
});

test('bug5: timestamp repair', () => {
  const fixed = repairCues([
    { start: 2000, end: 1000, text: 'reversed' },
    { start: 3000, end: 3100, text: 'short' },
    { start: 3300, end: 9000, text: 'overlap' },
    { start: 15000, end: 16000, text: 'clean' },
  ]);
  assert.equal(fixed[0].end - fixed[0].start, 500);
  assert.ok(fixed[1].end - fixed[1].start >= 500);
  assert.ok(fixed[2].start >= fixed[1].end);
  assert.equal(fixed[3].start, 15000);
});

test('si<->sin normalization (exact-match audit fix)', () => {
  assert.equal(toSin('si'), 'sin');
  assert.equal(toSin('sin'), 'sin');
  assert.equal(toSin('SIN'), 'sin');
  assert.equal(toSin('eng'), 'eng');
  // the rank() filter AnantPlay applies (osCode().equals()) can never drop a 'sin' row
  const rows = rank([{ id: 'a', name: 'x', lang: 'si', url: 'u', origin: 'piratelk', score: 1, human: true }]);
  assert.equal(rows.length, 1);
  assert.equal(rows[0].lang, 'sin');
});

test('parseVideoId', () => {
  assert.deepEqual(parseVideoId('movie', 'tt0468569'), { imdb: 'tt0468569', season: 0, episode: 0 });
  assert.deepEqual(parseVideoId('series', 'tt0944947:1:2'), { imdb: 'tt0944947', season: 1, episode: 2 });
  assert.equal(parseVideoId('movie', 'xyz'), null);
});

test('cue aligner: constant offset found on synthetic timelines', () => {
  const ref = Array.from({ length: 60 }, (_, i) => (i + 1) * 2000);
  const shifted = ref.map((t) => t + 1500);   // +1.5 s
  const fit = bestLinearFit(ref, shifted);
  assert.ok(Math.abs(fit.offsetMs - -1500) < 60, `offset ${fit.offsetMs}`);   // target = ref + 1.5 s -> offset -1500
  assert.ok(fit.score > 0.8, `score ${fit.score}`);
  // offset maps TARGET cues onto the REFERENCE timeline: tgt(2000) - 1500 = ref(500)... use a target cue:
  const applied = applyAlign([{ start: 4000, end: 5000, text: 'x' }], fit.offsetMs);
  assert.ok(Math.abs(applied[0].start - 2500) < 60, `aligned start ${applied[0].start}`);
});

test('cue aligner speed: 1500 cues < 3 ms', () => {
  const ref = Array.from({ length: 1500 }, (_, i) => 1000 + i * 2500 + (i % 7) * 30);
  const tgt = ref.map((t) => t + 1200);
  const t0 = performance.now();
  bestLinearFit(ref, tgt);
  const ms = performance.now() - t0;
  assert.ok(ms < 40, `took ${ms.toFixed(2)} ms (budget: Worker CPU 10 ms per request, aligner runs in waitUntil)`);
});

test('emit/parse roundtrip + UTF-16LE decode', () => {
  const cues = parseSrt('1\n00:00:01,000 --> 00:00:02,500\nHello\nworld\n');
  assert.equal(cues[0].text, 'Hello\nworld');
  assert.ok(emitSrt(cues).includes('00:00:01,000 --> 00:00:02,500'));
  const u16 = new Uint8Array([0xff, 0xfe, 0x31, 0x00, 0x00, 0x00, 0x0a]);
  assert.equal(decode(u16).includes('1'), true);
  assert.equal(stripMarkup('{\\an8}<font color="red">hi</font>'), 'hi');
  assert.equal(tc(61500), '00:01:01,500');   // 61.5 s
});

test('wrap: sinhala-safe 38-42 chars', () => {
  const w = wrap('මෙය ඉතා දිග සිංහල එක්සතැනක ඇති දිග පේළියක් වන අතර එය එසැසැස්මට වඩා දිගු ය', 40);
  assert.ok(w.includes('\n'));
  for (const l of w.split('\n')) assert.ok(l.length <= 45, l.length);
});

test('router: live piratelk search returns rows (network)', { timeout: 30000 }, async () => {
  const hits = await searchPiratelk('tt0468569', 0, 0, 'The Dark Knight 2008');
  assert.ok(Array.isArray(hits));
  assert.ok(hits.length >= 0, 'no throw counts as pass; live site variance');
});

// helper: names from a real zip (fflate ESM import)
import { unzipSync } from '../vendor/fflate.esm.js';
const unzipNames = (b: Uint8Array): string[] => Object.keys(unzipSync(b));
