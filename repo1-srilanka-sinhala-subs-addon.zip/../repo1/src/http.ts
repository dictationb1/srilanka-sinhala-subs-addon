/**
 * http.ts — fetch that works in BOTH runtimes. In the Cloudflare Worker it is the
 * platform fetch (Workers' own TLS stack — no CF JA3 issue in production). Under
 * plain Node (sandbox tests, GitHub Actions pre-indexer) some Cloudflare-fronted
 * sites block Node's TLS fingerprint; those calls transparently fall back to curl.
 */
export const BROWSER_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

const isNode = typeof globalThis.process?.versions?.node === 'string' && typeof (globalThis as any).WebSocketPair === 'undefined';

export async function httpGet(url: string, headers: Record<string, string>, timeoutMs = 25000): Promise<{ status: number; bytes: Uint8Array; text: string }> {
  let r: { status: number; bytes: Uint8Array; text: string };
  try {
    const res = await fetch(url, { headers, redirect: 'follow', signal: AbortSignal.timeout(timeoutMs) });
    const ab = await res.arrayBuffer();
    r = { status: res.status, bytes: new Uint8Array(ab), text: new TextDecoder().decode(ab) };
  } catch (e) {
    if (!isNode) throw e;   // Workers runtime: no fallback exists, surface the error
    return curlGet(url, headers, timeoutMs);
  }
  // Node's TLS fingerprint is blocked by some Cloudflare sites (sandbox/CI only;
  // the Workers runtime uses its own stack and is unaffected). Retry those via curl.
  const blocked = r.status === 403 || r.status === 429 || (r.status === 503 && r.text.includes('Just a moment'));
  if (blocked && isNode) return curlGet(url, headers, timeoutMs);
  return r;
}

async function curlGet(url: string, headers: Record<string, string>, timeoutMs: number): Promise<{ status: number; bytes: Uint8Array; text: string }> {
  const args = ['-sL', '-m', String(Math.round(timeoutMs / 1000)), '-w', '\n%{http_code}'];
  for (const [k, v] of Object.entries(headers)) args.push('-H', `${k}: ${v}`);
  args.push(url);
  const { execFile } = await import('node:child_process');
  const { promisify } = await import('node:util');
  const out = (await promisify(execFile as any)('curl', args, { maxBuffer: 64 * 1024 * 1024, encoding: 'buffer' })) as { stdout: Buffer };
  const body = Buffer.from(out.stdout);
  const nl = body.lastIndexOf(10);
  const status = +(body.subarray(nl + 1).toString().trim() || 0);
  const bytes = body.subarray(0, nl);
  return { status, bytes: new Uint8Array(bytes), text: bytes.toString('utf-8') };
}
