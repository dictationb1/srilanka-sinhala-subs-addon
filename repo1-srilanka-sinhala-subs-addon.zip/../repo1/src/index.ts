/**
 * index.ts — srilanka-sinhala-subs-addon: Stremio-protocol subtitle addon on a
 * Cloudflare Worker (pure TS: fflate for zip/gzip, NO Python/Rust/unrar — RAR is
 * served from the nightly pre-indexer's R2 cache).
 *
 * Routes:
 *   GET /manifest.json
 *   GET /subtitles/:type/:id.json[?videoRelease=]      -> Stremio rows ("lang":"sin")
 *   GET /download/:token.srt                            -> clean UTF-8 SRT; 202 while translating
 *   GET /health                                         -> per-source live check
 *
 * 202 protocol (audit fix 3): AnantPlay's SubFetch.java never reads HTTP status
 * (Warp.connect returns the stream; a non-200 body simply fails the `-->` sniff),
 * so the FORK retries after 10 s / 25 s with a Toast; standard Stremio clients
 * poll the same URL until 200. Retry-After headers carry the schedule.
 */
import { toSin, rank, parseVideoId, releaseScore } from './match.ts';
import { parseSrt, emitSrt, stripMarkup, type Cue } from './srt.ts';
import { extract, isWatermark, repairCues, wrap, type FetchedSub } from './normalize.ts';
import { cacheGet, cachePut, tryLock, unlock, keyForUrl } from './cache.ts';
import { searchPiratelk, toRows as plRows, fetchPiratelk } from './sources/piratelk.ts';
import { searchZoomlk, toRows as zlRows, fetchZoomlk } from './sources/zoomlk.ts';
import { searchOpenSubs, toRows as osRows, fetchOpenSubs } from './sources/opensubsLegacy.ts';
import { searchSubdl } from './sources/subdl.ts';
import { translateSrt as geminiTranslate } from './translate/geminiFlash.ts';
import { translateSrt as googleTranslate } from './translate/googleV3.ts';

export interface Env { SUBS_BUCKET?: R2Bucket; SUBS_INDEX?: KVNamespace; GEMINI_API_KEY?: string; GOOGLE_TRANSLATE_KEY?: string; SUBDL_API_KEY?: string; TRANSLATOR_PROVIDER?: string }

const ADDON_NAME = 'Sri Lanka Sinhala Subtitles';
const IDS = { piratelk: 'srilanka-sinhala-subs', version: '1.0.0' } as const;

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
};

const json = (body: unknown, status = 200, extra: Record<string, string> = {}) =>
  new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json', ...CORS, ...extra } });

const err = (status: number, msg: string) => new Response(JSON.stringify({ error: msg }), { status, headers: { 'Content-Type': 'application/json', ...CORS } });

export default {
  async fetch(req: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    const u = new URL(req.url);
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
    const path = u.pathname.replace(/\/$/, '');
    try {
      if (path === '/manifest.json') return json(manifest(u));
      if (path === '/health') return json(await health());
      const sub = path.match(/^\/subtitles\/(movie|series)\/([a-z0-9:.\-]+)\.json$/i);
      if (sub) return await subtitlesRoute(req, u, sub[1].toLowerCase(), sub[2], env);
      const dl = path.match(/^\/download\/([a-z0-9]{8,64})\.srt$/i);
      if (dl) return await downloadRoute(req, dl[1], env, ctx);
      return err(404, 'not found');
    } catch (e) {
      return err(500, String((e as Error)?.message ?? e));
    }
  },
};

function manifest(u: URL) {
  return {
    id: IDS.piratelk,
    name: ADDON_NAME,
    description: 'සිංහල උපසිරැසි — piratelk.com + zoom.lk + OpenSubtitles, plus English->Sinhala translation when no Sinhala file exists.',
    version: IDS.version,
    resources: { subtitles: { types: ['movie', 'series'], idPrefixes: ['tt'] } },
    types: ['movie', 'series'],
    idPrefixes: ['tt'],
    config: `${u.protocol}//${u.host}/manifest.json`,
  };
}

async function subtitlesRoute(req: Request, u: URL, type: string, id: string, env: Env): Promise<Response> {
  const vid = parseVideoId(type, id);
  if (!vid) return json({ subtitles: [] });
  const videoRelease = u.searchParams.get('videoRelease') ?? u.searchParams.get('name') ?? '';
  const rows = await collectRows(vid, videoRelease, env);
  return json({ subtitles: rows, cacheMaxAge: 3600 });
}

export interface Row { id: string; name: string; lang: string; url: string; downloads?: number; hearingImpaired?: boolean; origin: string; score: number; human: boolean }

async function collectRows(vid: { imdb: string; season: number; episode: number }, videoRelease: string, env: Env): Promise<Row[]> {
  const title = titleFromRelease(videoRelease);
  const tasks: Promise<any[]> = [
    searchOpenSubs(vid.imdb, vid.season, vid.episode, 'sin').then(osRows).catch(() => []),
    searchPiratelk(vid.imdb, vid.season, vid.episode, videoRelease).then((h) => plRows(h, videoRelease)).catch(() => []),
    searchZoomlk(title, vid.imdb, vid.season, vid.episode).then((h) => zlRows(h, videoRelease)).catch(() => []),
    env.SUBDL_API_KEY ? searchSubdl(vid.imdb, vid.season, vid.episode, env.SUBDL_API_KEY).catch(() => []) : Promise.resolve([]),
  ];
  const [os, pl, zl] = await Promise.all(tasks);
  const all = [...os, ...pl, ...zl];
  // English reference row (translated on demand) only when no human Sinhala exists
  if (all.length === 0) {
    const eng = await searchOpenSubs(vid.imdb, vid.season, vid.episode, 'eng').catch(() => []);
    if (eng.length) {
      const best = eng[0];
      const token = await keyForUrl(best.url + '|sin|translated');
      await env.SUBS_INDEX?.put(`row:${token}`, JSON.stringify({ origin: 'opensubsLegacy', url: best.url, lang: 'eng', release: best.name })).catch(() => {});
      return [{
        id: `gemini:${token}`, name: `Sinhala (auto-translated) — ${best.name}`, lang: 'sin', url: `/download/${token}.srt`,
        origin: 'geminiTranslated', score: 0.15, human: false, downloads: best.downloads,
      }];
    }
  }
  return rank(all, 'sin');
}

const titleFromRelease = (r: string) => (r || '').replace(/[._]/g, ' ').replace(/\s*\(?\d{4}\)?.*$/, '').trim().slice(0, 60);

/** GET /download/<token>.srt — extract, normalize, cache; 202 while translating. */
async function downloadRoute(req: Request, token: string, env: Env, ctx: ExecutionContext): Promise<Response> {
  const headers = { 'Content-Type': 'text/plain; charset=utf-8', ...CORS, 'Cache-Control': 'public, max-age=86400' };
  const rowRaw = await env.SUBS_INDEX?.get(`row:${token}`);
  if (!rowRaw) return err(404, 'unknown token');
  const row = JSON.parse(rowRaw) as { origin: string; url: string; lang: string; release?: string };

  const cached = await cacheGet(env, row.url + '|sin');
  if (cached && cached.text) return new Response(cached.text, { status: 200, headers });

  const bytes = await fetchOrigin(row.origin, row.url);
  const sub = await extract(bytes);
  if (sub.note?.startsWith('rar:')) {
    // RAR never decompressed in-Worker: the nightly GitHub Actions pre-indexer
    // uploads to R2 under this key; if absent, tell the client to retry later.
    const pre = await cacheGet(env, `preindex:${row.url}`);
    if (pre && pre.text) return new Response(pre.text, { status: 200, headers });
    return new Response('RAR archive pending nightly pre-index', { status: 202, headers: { ...headers, 'Retry-After': '3600' } });
  }

  let text = normalizeToSrt(sub);
  if (row.lang === 'eng' || row.origin === 'geminiTranslated') {
    // translation path
    const provider = env.TRANSLATOR_PROVIDER === 'google_v3' ? 'google' : 'gemini';
    const key = provider === 'google' ? env.GOOGLE_TRANSLATE_KEY : env.GEMINI_API_KEY;
    if (!key) return new Response('translator not configured', { status: 503, headers });
    if (!(await tryLock(env, token))) {
      // another invocation is already translating
      return new Response('translation in progress', { status: 202, headers: { ...headers, 'Retry-After': '10' } });
    }
    const done = (async () => {
      try {
        const out = provider === 'google'
          ? await googleTranslate(key, text, { title: row.release ?? 'movie' })
          : await geminiTranslate(key, text, { title: row.release ?? 'movie' });
        await cachePut(env, row.url + '|sin', { text: out, ext: 'srt' });
      } finally {
        await unlock(env, token);
      }
    })();
    ctx.waitUntil(done);
    return new Response('translation started — poll again in ~10 s', { status: 202, headers: { ...headers, 'Retry-After': '10' } });
  }

  await cachePut(env, row.url + '|sin', { text, ext: 'srt' });
  return new Response(text, { status: 200, headers });
}

async function fetchOrigin(origin: string, url: string): Promise<Uint8Array> {
  switch (origin) {
    case 'piratelk': return fetchPiratelk(url);
    case 'zoomlk': return fetchZoomlk(+url.split('/').pop()!);
    case 'opensubsLegacy':
    case 'opensubsSin': return fetchOpenSubs(url);
    default: throw new Error(`unknown origin ${origin}`);
  }
}

function normalizeToSrt(sub: FetchedSub): string {
  const text = sub.text.replace(/^\uFEFF/, '');
  if (sub.ext === 'srt') {
    let cues: Cue[] = parseSrt(text);
    cues = cues.filter((c, i) => !isWatermark(stripMarkup(c.text), i, cues.length));
    cues = repairCues(cues);
    return emitSrt(cues);
  }
  // vtt/ass: convert cue bodies to SRT timing via parseSrt's tolerant parser
  const vtt = text.replace(/^WEBVTT.*$/m, '').replace(/^(\d{2}:\d{2})[.,](\d{3})/gm, '00:$1,$2');
  let cues = parseSrt(vtt);
  cues = cues.filter((c, i) => !isWatermark(stripMarkup(c.text), i, cues.length));
  cues = repairCues(cues);
  return emitSrt(cues);
}

async function health(): Promise<Record<string, unknown>> {
  const t0 = Date.now();
  const [os, pl, zl] = await Promise.all([
    fetch('https://rest.opensubtitles.org/search/sublanguageid-sin', { headers: { 'User-Agent': 'TemporaryUserAgent' } }).then((r) => r.status).catch(() => 0),
    fetch('https://piratelk.com/wp-json/wp/v2/posts?per_page=1', { method: 'GET', headers: { 'User-Agent': UA } }).then((r) => r.status).catch(() => 0),
    fetch('https://zoom.lk/robots.txt', { headers: { 'User-Agent': UA } }).then((r) => r.status).catch(() => 0),
  ]);
  return { ok: true, ms: Date.now() - t0, sources: { opensubtitles: os, piratelk: pl, 'zoom.lk': zl }, time: new Date().toISOString() };
}

