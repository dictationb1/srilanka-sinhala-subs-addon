/** srt.ts — cue parse/emit shared by the Worker and the test suite. */

export interface Cue { start: number; end: number; text: string }

const TIME = /^(\d{2,}):(\d{2}):(\d{2})[,.](\d{1,3})$/;

function ms(h: string, m: string, s: string, f: string): number {
  return (+h * 3600 + +m * 60 + +s) * 1000 + +f.padEnd(3, '0');
}

export function tc(millis: number): string {
  const t = Math.max(0, Math.round(millis));
  const h = Math.floor(t / 3600000), m = Math.floor(t / 60000) % 60, s = Math.floor(t / 1000) % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')},${String(t % 1000).padStart(3, '0')}`;
}

/** Parse an SRT-family file into cues. ASS/SSA/VTT input is pre-converted by normalize.ts callers. */
export function parseSrt(text: string): Cue[] {
  const out: Cue[] = [];
  const blocks = text.replace(/\r\n?/g, '\n').replace(/^\uFEFF/, '').split(/\n{2,}/);
  for (const blk of blocks) {
    const lines = blk.split('\n').filter((l) => l.trim() !== '');
    if (lines.length === 0) continue;
    let i = lines[0].trim().match(/^\d+$/) ? 1 : 0;
    if (i >= lines.length) continue;
    const m = lines[i].match(/(\d{2,}):(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*(\d{2,}):(\d{2}):(\d{2})[,.](\d{1,3})/);
    if (!m) continue;
    const start = ms(m[1], m[2], m[3], m[4]);
    const end = ms(m[5], m[6], m[7], m[8]);
    const body = lines.slice(i + 1).join('\n');
    if (body.trim() !== '') out.push({ start, end, text: body });
  }
  return out;
}

export function emitSrt(cues: readonly Cue[]): string {
  return cues
    .map((c, i) => `${i + 1}\n${tc(c.start)} --> ${tc(c.end)}\n${c.text}\n`)
    .join('\n');
}

/** Strip SRT markup the player would show raw: font/color/position tags. */
export function stripMarkup(t: string): string {
  return t
    .replace(/\{\\[^}]*\}/g, '')                       // {\an8\c&H...&}
    .replace(/<\/?(?:font|b|i|u|ruby|p|v|span)[^>]*>/gi, '')
    .trim();
}
