/**
 * zoomlk.ts — source adapter verified live 2026-11-20.
 *
 * LIVE FACTS (re-audited; supersedes Phase-1 "RAR" assumption):
 *  - robots.txt disallows ONLY /dlm_uploads/ — the interstitial /sub-download/<id>
 *    and post pages are allowed, so we never touch /dlm_uploads/ directly.
 *  - No WP REST (wp-json returns []); search works via ?s=<title> HTML.
 *  - Post page contains <a href="https://zoom.lk/sub-download/23752" class="sub-dl-btn">
 *    with "2,748 HITS" counter.
 *  - /sub-download/<id> -> Content-Type application/octet-stream, PK ZIP (deflate),
 *    flat entry "Elumale (2025) Kannada HQ HDRip.srt", UTF-8 BOM, 1513 cues,
 *    Sinhala verified (38,615 codepoints).
 *  - Slugs end with URL-encoded "සිංහල-උපසිරැසි" — percent-decode when linking.
 */
import { releaseScore } from '../match.ts';
import type { ScoredRow } from '../match.ts';
import { httpGet, BROWSER_UA } from '../http.ts';

const UA = BROWSER_UA;

export interface ZoomHit { postUrl: string; subDownloadId: number; title: string; hits: number }

export async function searchZoomlk(title: string, imdb: string, season: number, episode: number): Promise<ZoomHit[]> {
  const q = encodeURIComponent(title || imdb.replace(/^tt/, ''));
  const r = await httpGet(`https://zoom.lk/?s=${q}`, { 'User-Agent': UA, 'Accept-Language': 'en-US,en;q=0.9' });
  if (r.status !== 200) return [];
  const html = r.text;
  // search results list post links; then each post exposes sub-download/<id>
  const postLinks = [...new Set(html.match(/https:\/\/zoom\.lk\/[a-z0-9%.-]{8,}-sinhala-subtitle-[a-z0-9%-]*\//g) ?? [])].slice(0, 6);
  const out: ZoomHit[] = [];
  for (const u of postLinks) {
    const pr = await httpGet(u, { 'User-Agent': UA }).catch(() => null);
    if (!pr || pr.status !== 200) continue;
    const ph = pr.text;
    const id = ph.match(/href=['"]https:\/\/zoom\.lk\/sub-download\/(\d+)['"]/)?.[1];
    const hits = ph.match(/sub-dl-badge'?\s*>?\s*([\d,]+)\s*HITS/i)?.[1] ?? '0';
    if (id) out.push({ postUrl: u, subDownloadId: +id, title: decodeURIComponent(u).split('/').filter(Boolean).pop()!.replace(/-sinhala-subtitle.*/, ''), hits: +hits.replace(/,/g, '') });
    if (out.length >= 4) break;
  }
  return out;
}

export function toRows(hits: ZoomHit[], videoRelease: string): ScoredRow[] {
  return hits.map((h) => ({
    id: `zoomlk:${h.subDownloadId}`,
    name: h.title,
    lang: 'sin',
    url: `https://zoom.lk/sub-download/${h.subDownloadId}`,
    origin: 'zoomlk' as const,
    score: releaseScore(h.title, videoRelease) * 0.85 + 0.1,
    human: true,
    downloads: h.hits,
  }));
}

export async function fetchZoomlk(id: number): Promise<Uint8Array> {
  const r = await httpGet(`https://zoom.lk/sub-download/${id}`, { 'User-Agent': UA });
  if (r.status !== 200) throw new Error(`zoom.lk ${r.status}`);
  return r.bytes;
}
