/**
 * subdl.ts — optional source, OFF by default. SubDL's free API limits could not
 * be verified against live docs at audit time (marked UNVERIFIED in Phase 1), so
 * it is wired but returns [] unless SUBDL_API_KEY is set AND the endpoint still
 * answers with the documented shape; any failure degrades silently.
 * Enable with: wrangler secret put SUBDL_API_KEY.
 */
import type { ScoredRow } from '../match.ts';

interface SubDlEntry { SubFileName?: string; language?: string; SubDownloadLink?: string; SubDownloads?: number }

export async function searchSubdl(imdb: string, season: number, episode: number, apiKey: string): Promise<ScoredRow[]> {
  if (!apiKey) return [];
  const parts = [`imdb_id=${imdb}`];
  if (season > 0) parts.push(`season=${season}`, episode > 0 ? `episode=${episode}` : 'type=tv');
  const url = `https://api.subdl.com/api/v1/subtitles?${parts.join('&')}`;
  const r = await fetch(url, { headers: { Authorization: `Bearer ${apiKey}` } }).catch(() => null);
  if (!r || !r.ok) return [];
  const j = await r.json().catch(() => null);
  const subs: SubDlEntry[] = j?.subtitles ?? j?.results ?? [];
  return subs
    .filter((s) => (s.language ?? '').toLowerCase().startsWith('si'))
    .map((s) => ({
      id: `subdl:${s.SubFileName ?? Math.random().toString(36).slice(2)}`,
      name: s.SubFileName ?? 'subtitle',
      lang: 'sin',
      url: s.SubDownloadLink ?? '',
      origin: 'subdl' as const,
      score: 0.18,
      human: true,
      downloads: +(s.SubDownloads ?? 0),
    }))
    .filter((r2) => r2.url !== '');
}
