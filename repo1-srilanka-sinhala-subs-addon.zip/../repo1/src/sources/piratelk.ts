/**
 * piratelk.ts — source adapter verified live 2026-11-20.
 *
 * LIVE FACTS (re-audited):
 *  - robots.txt: "User-agent: * Disallow:" (fully open; only wp-admin implicitly).
 *  - WP REST API bypasses the site's Cloudflare search wall: /wp-json/wp/v2/posts?search=...
 *    returns JSON with slug, link, IMDb IDs and the DLM download href (HTTP 200, 422 KB).
 *  - Download: /download/<slug>/?tmstv=<ts> -> Content-Type application/zip, NESTED folder:
 *    "The Dark Knight (2008) - Piratelk.com/<name>.srt" + PirateLk.txt ad + sometimes a
 *    UTF-16LE variant. UTF-8 w/ BOM, ~1881 cues, Sinhala verified (53,610 codepoints).
 */
import { releaseScore, toSin } from '../match.ts';
import type { ScoredRow } from '../match.ts';

import { httpGet, BROWSER_UA } from '../http.ts';
const UA = BROWSER_UA;

export interface SourceHit { slug: string; postUrl: string; title: string; imdb?: string; dlUrl: string; release?: string }

export async function searchPiratelk(imdb: string, season: number, episode: number, videoName = ''): Promise<SourceHit[]> {
  // The API needs the title, not the id: strip the year from the release name, fall back to imdb digits.
  const q = encodeURIComponent(titleFrom(videoName) || imdb.replace(/^tt/, ''));
  const r = await httpGet(`https://piratelk.com/wp-json/wp/v2/posts?search=${q}&per_page=10`, {
    'User-Agent': UA, Accept: 'application/json',
  });
  if (r.status !== 200) return [];
  const posts: any[] = JSON.parse(r.text).length ? JSON.parse(r.text) : [];
  const out: SourceHit[] = [];
  for (const p of posts) {
    const html: string = p?.content?.rendered ?? '';
    const ids = html.match(/tt\d{7,8}/g) ?? [];
    const dl = html.match(/href="([^"]*\/download\/[^"]*)"/)?.[1] ?? '';
    if (!dl) continue;
    if (imdb && ids.length && !ids.includes(imdb)) continue;   // wrong movie safety
    const dlUrl = dl.replace(/&amp;/g, '&');
    const slug: string = p?.slug ?? '';
    const title: string = stripTitle(p?.title?.rendered ?? slug);
    out.push({ slug, postUrl: p?.link ?? '', title, imdb: ids.find((x) => x !== 'tt5463162'), dlUrl, release: title });
  }
  return out;
}

const titleFrom = (release: string) => (release || '').replace(/[._]/g, ' ').replace(/\s*\(?\d{4}\)?.*$/, '').trim().slice(0, 60);

const stripTitle = (t: string) => (t || '').replace(/&#8211;|&#8212;/g, '-').replace(/<[^>]+>/g, '').replace(/\s*සිංහල.*$/, '').trim();

/** Convert hits to Stremio rows, scored against the video release name. */
export function toRows(hits: SourceHit[], videoRelease: string): ScoredRow[] {
  return hits.map((h) => ({
    id: `piratelk:${h.slug}`,
    name: h.title,
    lang: 'sin',
    url: h.dlUrl,
    origin: 'piratelk' as const,
    score: releaseScore(h.release ?? h.title, videoRelease) * 0.9 + 0.1,
    human: true,
    downloads: 0,
  }));
}

export async function fetchPiratelk(dlUrl: string): Promise<Uint8Array> {
  const r = await httpGet(dlUrl, { 'User-Agent': UA, Accept: '*/*' });
  if (r.status !== 200) throw new Error(`piratelk ${r.status}`);
  return r.bytes;
}
