/**
 * match.ts — release-tag scorer (audit fix 3) + the si<->sin normalizer used
 * everywhere (addon rows, fork patch, cache keys). Exact-Match audit fix:
 * AnantPlay filters Stremio rows with `osCode(s.lang).equals(code)` (Subs.java:71),
 * so rows MUST carry ISO 639-2 "sin", never "si".
 */

/** Canonical language code AnantPlay expects: ISO 639-2/B "sin" for Sinhala. */
export function toSin(lang: string): string {
  const l = (lang || '').trim().toLowerCase();
  return l === 'si' || l === 'sin' || l === 'si-lk' || l === 'sinh' ? 'sin' : l;
}

/** Stremio clients may send either; normalize query params the same way. */
export function normLangParam(v: string | null | undefined): string | undefined {
  if (!v) return undefined;
  const l = toSin(v);
  return l.length === 2 || l.length === 3 ? l : undefined;
}

const STOP = new Set(['brrip', 'bluray', 'blu-ray', 'webrip', 'web', 'webdl', 'web-dl', 'dvdrip', 'dvdscr', 'hdtv',
  'hdrip', 'camrip', 'hd', 'sd', 'hq', 'hdrc', 'hdr', 'aac', 'ac3', 'dts', 'dolby', 'x264', 'x265', 'h264', 'h265',
  'hevc', 'xvid', 'divx', 'avc', '1080p', '720p', '480p', '360p', '2160p', 'mp3', 'aac2', '10bit', '8bit', 'remastered',
  'extended', 'unrated', 'imax', 'proper', 'repack', 'internal', 'limited', 'complete', 'season', 's01']);

const tokenize = (s: string): string[] =>
  (s || '').toLowerCase().replace(/[._[\]()]+/g, ' ').split(/[\s-]+/).filter((t) => t.length > 1 && !STOP.has(t));

/**
 * Fixed release-tag scorer: lowercase Jaccard over tokens (audit fix 3) +
 * release-group capture AFTER the final hyphen (-ntb, -yts, -avc, -flux).
 */
export function releaseScore(subRelease: string, videoRelease: string): number {
  const pick = (s: string): { tokens: Set<string>; group: string } => {
    const raw = (s || '').toLowerCase().trim();
    const group = (raw.split('-').pop() || '').replace(/[^\w]/g, '');
    return { tokens: new Set(tokenize(raw)), group };
  };
  const a = pick(subRelease), b = pick(videoRelease);
  if (a.tokens.size === 0 || b.tokens.size === 0) return 0;
  let inter = 0;
  for (const t of a.tokens) if (b.tokens.has(t)) inter++;
  let j = inter / (a.tokens.size + b.tokens.size - inter);
  if (a.group && a.group === b.group && a.group.length >= 2) j = Math.min(1, j + 0.25);   // same ripper
  const yearA = subRelease.match(/(19|20)\d{2}/)?.[0], yearB = videoRelease.match(/(19|20)\d{2}/)?.[0];
  if (yearA && yearB && yearA !== yearB) j *= 0.5;   // 2007 vs 2008 rips are different cuts
  return j;
}

export interface ScoredRow {
  id: string;
  name: string;
  lang: string;
  url: string;
  downloads?: number;
  hearingImpaired?: boolean;
  origin: 'piratelk' | 'zoomlk' | 'opensubsLegacy' | 'opensubsSin' | 'subdl' | 'geminiTranslated' | 'preindexed';
  score: number;
  human: boolean;
}

/** Sort: exact lang first, then score, then downloads. */
export function rank(rows: ScoredRow[], wantLang = 'sin'): ScoredRow[] {
  return rows
    .map((r) => ({ ...r, lang: toSin(r.lang) }))
    .filter((r) => r.lang === toSin(wantLang))
    .sort((a, b) => (b.human - a.human) || (b.score - a.score) || ((b.downloads || 0) - (a.downloads || 0)));
}

/** IMDb / season / episode extractor for the Stremio route params. */
export function parseVideoId(type: string, id: string): { imdb: string; season: number; episode: number } | null {
  const imdb = id.match(/tt\d{1,9}/)?.[0];
  if (!imdb) return null;
  if (type === 'series') {
    const m = id.match(/:(\d+):(\d+)$/);
    return { imdb, season: m ? +m[1] : 0, episode: m ? +m[2] : 0 };
  }
  return { imdb, season: 0, episode: 0 };
}
