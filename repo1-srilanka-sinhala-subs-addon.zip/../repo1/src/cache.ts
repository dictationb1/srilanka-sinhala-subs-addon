/**
 * cache.ts — R2 permanent cache with a KV-only fallback (fix: zero-cost path
 * when R2 is not enabled on the account). Cache keys are content-addressed by
 * SHA-1 of the upstream URL, exactly like AnantPlay's SubFetch.java caching.
 */
import type { FetchedSub } from './normalize.ts';

export interface Env {
  SUBS_BUCKET?: R2Bucket;
  SUBS_INDEX?: KVNamespace;
  GEMINI_API_KEY?: string;
  GOOGLE_TRANSLATE_KEY?: string;
  SUBDL_API_KEY?: string;
  TRANSLATOR_PROVIDER?: 'gemini' | 'google_v3';
}



export async function sha1hex(s: string): Promise<string> {
  const d = await crypto.subtle.digest('SHA-1', new TextEncoder().encode(s));
  return [...new Uint8Array(d)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

export async function cacheGet(env: Env, url: string): Promise<FetchedSub | null> {
  const key = await keyForUrl(url);
  if (env.SUBS_BUCKET) {
    const o = await env.SUBS_BUCKET.get(key).catch(() => null);
    if (!o) return null;
    return { text: await o.text(), ext: ((o as any).customMetadata?.ext ?? 'srt') as FetchedSub['ext'] };
  }
  if (!env.SUBS_INDEX) return null;
  return await env.SUBS_INDEX.get<FetchedSub>(key, 'json').catch(() => null);
}

export async function cachePut(env: Env, url: string, sub: FetchedSub): Promise<void> {
  if (sub.ext === 'srt' && sub.text === '') return;   // never cache a routing note as a subtitle
  const key = await keyForUrl(url);
  if (env.SUBS_BUCKET) {
    await env.SUBS_BUCKET.put(key, sub.text, { customMetadata: { ext: sub.ext } } as R2PutOptions).catch(() => {});
    return;
  }
  if (!env.SUBS_INDEX) return;
  await env.SUBS_INDEX.put(key, JSON.stringify(sub)).catch(() => {});
}

/** A lock held while a translation job runs, so retries don't double-spend (KV-only fallback included). */
export async function tryLock(env: Env, token: string, ttlSeconds = 600): Promise<boolean> {
  const key = `lock:${token}`;
  const existing = await env.SUBS_INDEX!.get(key).catch(() => null);
  if (existing) return false;
  await env.SUBS_INDEX!.put(key, String(Date.now()), { expirationTtl: ttlSeconds }).catch(() => {});
  return true;
}

export async function unlock(env: Env, token: string): Promise<void> {
  await env.SUBS_INDEX!.delete(`lock:${token}`).catch(() => {});
}

export const keyForUrl = (url: string) => sha1hex('anant-sin:' + url).then((h) => `sub:${h}`);
