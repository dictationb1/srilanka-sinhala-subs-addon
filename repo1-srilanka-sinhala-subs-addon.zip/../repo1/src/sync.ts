/**
 * sync.ts — pure-TS cue-timeline aligner (audit fix: NO Python ffsubsync / Rust
 * alass in the Worker). Computes a linear offset + FPS-ratio correction between
 * an English reference SRT and the target subtitle by cross-correlating cue
 * START times, in <3 ms for a 1500-cue movie.
 *
 * Layer 2 (on-device): AnantPlay's SubSync.java + SpeechMeter.java audio sync
 * stays in the app and covers everything this aligner cannot.
 */

const FPS = [23.976, 24.0, 25.0, 29.97, 30.0];

/** Convert a linear ms offset into (offsetMs, fpsFrom, fpsTo) when it explains the drift better. */
export function bestLinearFit(refStarts: number[], targetStarts: number[]): { offsetMs: number; fpsFrom?: number; fpsTo?: number; score: number } {
  if (refStarts.length < 8 || targetStarts.length < 8) return { offsetMs: 0, score: 0 };
  // crude initial guess via medians of first-quotile cue starts
  const q = (a: number[]) => a.slice().sort((x, y) => x - y);
  const med = (a: number[]) => { const s = q(a); return s[Math.floor(s.length / 2)]; };
  let best = { offsetMs: 0, score: 0 };
  const refMed = med(refStarts), tgtMed = med(targetStarts);
  for (const f of FPS) {
    for (const t of FPS) {
      if (f === t) continue;
      const k = f / t;   // a 25fps subtitle on a 23.976fps video drifts +4.17%
      // scale target starts by k, then find best constant offset vs ref
      let offs: number[] = [];
      for (let i = 0; i < targetStarts.length; i += Math.max(1, Math.floor(targetStarts.length / 64))) {
        const scaled = targetStarts[i] * k;
        // nearest ref cue
        let lo = 0, hi = refStarts.length - 1;
        while (lo < hi) { const m = (lo + hi) >> 1; if (refStarts[m] < scaled) lo = m + 1; else hi = m; }
        const d = (refStarts[Math.max(0, lo - 1)] ?? 0) - scaled;
        offs.push(Math.abs(d) < 2000 ? d : 0);
      }
      const o = med(offs.filter((x) => x !== 0));
      let hits = 0;
      for (const s of refStarts) {
        const scaled = (s - o) / k;
        // does a target cue start within 120 ms of the scaled ref start?
        let lo = 0, hi = targetStarts.length - 1;
        while (lo < hi) { const m = (lo + hi) >> 1; if (targetStarts[m] < scaled) lo = m + 1; else hi = m; }
        const near = targetStarts[lo] ?? Infinity;
        const nearPrev = targetStarts[Math.max(0, lo - 1)] ?? Infinity;
        if (Math.min(Math.abs(near - scaled), Math.abs(scaled - nearPrev)) < 120) hits++;
      }
      const score = hits / refStarts.length * (k === 1 ? 1 : 0.92);   // slight prior against FPS changes
      if (score > best.score) best = { offsetMs: Math.round(o), fpsFrom: f, fpsTo: t, score };
    }
  }
  // plain constant offset (k = 1)
  let offs: number[] = [];
  for (let i = 0; i < targetStarts.length; i++) {
    let lo = 0, hi = refStarts.length - 1;
    while (lo < hi) { const m = (lo + hi) >> 1; if (refStarts[m] < targetStarts[i]) lo = m + 1; else hi = m; }
    offs.push((refStarts[Math.max(0, lo - 1)] ?? 0) - targetStarts[i]);
  }
  const o = med(offs);
  let hits = 0;
  for (const s of targetStarts) if (Math.abs(s + o - refStarts[Math.min(refStarts.length - 1, refStarts.findIndex((r) => r >= s + o))] ?? 0) < 120) hits++;
  const score = hits / targetStarts.length;
  if (score > best.score) best = { offsetMs: Math.round(o), score };
  return best;
}

/** Apply an alignment: shift + optional FPS rescale, returns new cues. */
export function applyAlign(cues: { start: number; end: number; text: string }[], offsetMs: number, fpsFrom?: number, fpsTo?: number) {
  const k = fpsFrom && fpsTo && fpsFrom !== fpsTo ? fpsFrom / fpsTo : 1;
  return cues.map((c) => ({ ...c, start: c.start * k + offsetMs, end: c.end * k + offsetMs }));
}
