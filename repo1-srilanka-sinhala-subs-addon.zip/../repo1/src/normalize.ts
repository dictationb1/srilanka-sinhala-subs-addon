/**
 * normalize.ts — bytes of any subtitle container -> clean UTF-8 .srt text
 *
 * Mirrors AnantPlay's SubFetch.java semantics, with the audit fixes applied:
 *  - nested-folder ZIP entries are walked (piratelk packs "<Movie>/name.srt")
 *  - __MACOSX/ and path traversal are rejected, entries at ANY depth are ranked
 *  - gzip (OpenSubtitles .gz), ZIP (piratelk / zoom.lk), UTF-16LE BOM variants
 *  - RAR4/5 and 7z are routed to the nightly pre-indexer, never thrown away
 */
import { unzipSync, gunzipSync } from '../vendor/fflate.esm.js';
import type { Cue } from './srt.js';

export const SUB_EXTS = ['srt', 'ass', 'ssa', 'vtt'] as const;
export type SubExt = (typeof SUB_EXTS)[number];
const RANK: Record<SubExt, number> = { srt: 0, ass: 1, ssa: 1, vtt: 2 };
export const MAX_ARCHIVE_BYTES = 5 * 1024 * 1024;   // same zip-bomb cap as SubFetch.java MAX

export interface FetchedSub { text: string; ext: SubExt; note?: string }

const safeName = (n: string): boolean =>
  n.length > 0 && !n.startsWith('/') && !n.includes('\\') && !n.includes('..') && !n.startsWith('.');

/** Detect gzip / zip / rar4 / rar5 / 7z magic. */
export function kind(b: Uint8Array): 'gzip' | 'zip' | 'rar4' | 'rar5' | '7z' | 'raw' {
  if (b.length >= 2 && b[0] === 0x1f && b[1] === 0x8b) return 'gzip';
  if (b.length >= 4 && b[0] === 0x50 && b[1] === 0x4b && b[2] === 3 && b[3] === 4) return 'zip';
  if (b.length >= 8 && b[0] === 0x52 && b[1] === 0x61 && b[2] === 0x72 && b[3] === 0x21 && b[4] === 0x1a && b[5] === 0x07) {
    return b[6] === 0x00 ? 'rar4' : 'rar5';
  }
  if (b.length >= 6 && b[0] === 0x37 && b[1] === 0x7a && b[2] === 0xbc && b[3] === 0xaf && b[4] === 0x27 && b[5] === 0x1c) return '7z';
  return 'raw';
}

/**
 * Entry picker for a zip: prefers .srt > .ass/.ssa > .vtt at ANY folder depth
 * (audit fix 1), skipping __MACOSX/, dotfiles, dirs and unsafe names.
 */
export function pickZipEntry(names: readonly string[]): { name: string; ext: SubExt } | null {
  let best: { name: string; ext: SubExt } | null = null;
  for (const raw of names) {
    const n = raw.endsWith('/') ? raw.slice(0, -1) : raw;
    if (n.length === 0 || !safeName(n) || n.includes('__MACOSX') || n.startsWith('._')) continue;
    const ext = n.toLowerCase().split('.').pop() as SubExt;
    if (!(ext in RANK)) continue;
    if (best && RANK[best.ext] <= RANK[ext]) continue;
    best = { name: n, ext };
  }
  return best;
}

/** UTF-8 / UTF-16LE-BOM / windows-1252 decode to text, mirroring SubFetch.pick(). */
export function decode(b: Uint8Array, hint = ''): string {
  if (b.length >= 3 && b[0] === 0xef && b[1] === 0xbb && b[2] === 0xbf) return new TextDecoder('utf-8').decode(b.subarray(3));
  if (b.length >= 2 && b[0] === 0xff && b[1] === 0xfe) return new TextDecoder('utf-16le').decode(b.subarray(2));
  const t = new TextDecoder('utf-8', { fatal: true }).decode(b);
  return t;
}

/** Packed subtitle bytes -> UTF-8 SRT-family text. RAR/7z -> note that names the pre-indexer route. */
export async function extract(data: ArrayBuffer | Uint8Array): Promise<FetchedSub> {
  const b = data instanceof Uint8Array ? data : new Uint8Array(data);
  const k = kind(b);
  if (k === 'gzip') {
    const out = gunzipSync(b);
    return { text: decode(out), ext: 'srt' };
  }
  if (k === 'zip') {
    if (b.length > MAX_ARCHIVE_BYTES) throw new Error('archive over 5 MB cap');
    const z = unzipSync(b, { filter: (f) => f.originalSize <= MAX_ARCHIVE_BYTES });
    const pick = pickZipEntry(Object.keys(z));
    if (!pick) throw new Error('no subtitle entry in zip');
    return { text: decode(z[pick.name]!), ext: pick.ext };
  }
  if (k === 'rar4' || k === 'rar5')
    return { text: '', ext: 'srt', note: `rar:${k}` };   // served pre-extracted from R2 by the nightly job; never in-Worker
  if (k === '7z') return { text: '', ext: 'srt', note: '7z:route-to-preindexer' };
  return { text: decode(b), ext: 'srt' };
}

/**
 * Safe watermark/credit filter (audit fix 2): strips ad/watermark cues ONLY when
 * they are inside the first/last 5 cues or explicitly match known site names.
 * Real dialogue like "Credit card?" can never match.
 */
export const KNOWN_WATERMARK =
  /(opensubtitles|osdb|podnapisi|subscene|yifysubtitles|addic7ed|piratelk|pirate ?lk|zoom\.lk|zoom lk|sinhalasub|baiscope|cineru|my-subs|subsubtitle|subscene|divxsubtitle|subtitl(?:es)?\s*by|sync(?:ed|ing)?\s*by|www\.[a-z0-9-]+\.(?:lk|com|net|org)|https?:\/\/\S{6,}|\btranslated\s+by\b)/i;

export function isWatermark(text: string, cueIndex: number, totalCues: number, isFirst5 = true, isLast5 = true): boolean {
  const t = text.trim();
  if (t.length === 0) return false;
  if (t.length > 240) return false;   // a watermark is one short line; a long line is dialogue
  const first = isFirst5 && cueIndex < 5;
  const last = isLast5 && cueIndex >= totalCues - 5;
  if (first || last) {
    if (/^[\[(]?[\w .:-]{0,30}(?:credits?\b|synced\s+by|syncing\s+by|subtitles?\s+by\b|translated\s+by\b|subtitles?\s*:\s*$|ripped\s+by\b|encoded\s+by\b)\s*[\w .:()-]{0,40}\]?$/i.test(t)) return true;
    if (KNOWN_WATERMARK.test(t)) return true;
  }
  return KNOWN_WATERMARK.test(t) && !/[.!?…"'”]$|\b(is|are|was|the)\b/i.test(t);
}

/**
 * Timestamp repair (audit fix 5): clamp reversed cues, enforce 0.5 s minimum
 * duration, trim overlaps of up to 250 ms, keep the original text untouched.
 */
export function repairCues<T extends { start: number; end: number }>(cues: T[]): T[] {
  const out: T[] = [];
  let prevEnd = 0;
  for (const c of cues) {
    let { start, end } = c;
    if (!Number.isFinite(start) || !Number.isFinite(end)) continue;
    if (start < 0) start = 0;
    if (end <= start) end = start + 500;                      // reversed/zero cue -> half-second flash
    if (end - start < 500) end = start + 500;                 // min duration
    if (start < prevEnd && prevEnd - start <= 250) start = prevEnd;   // small overlap: nudge after the previous
    else if (start < prevEnd) end = Math.max(start + 500, end - 0);   // large overlap: keep, never move earlier
    out.push({ ...c, start, end });
    prevEnd = Math.max(prevEnd, end);
  }
  return out;
}

/** Sinhala-safe line wrap: 38–42 chars, split at spaces (Sinhala words are long). */
export function wrap(text: string, width = 40): string {
  const lines: string[] = [];
  for (const para of text.split('\n')) {
    if (para.length <= width) { lines.push(para); continue; }
    const words = para.split(' ');
    let cur = '';
    for (const w of words) {
      if (cur && (cur + ' ' + w).length > width) { lines.push(cur); cur = w; }
      else cur = cur ? cur + ' ' + w : w;
    }
    if (cur) lines.push(cur);
  }
  return lines.join('\n');
}
