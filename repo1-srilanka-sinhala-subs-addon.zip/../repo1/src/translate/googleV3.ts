/**
 * googleV3.ts — OPTIONAL secondary translator (env TRANSLATOR_PROVIDER=google_v3):
 * Google Cloud Translation v3 via API key. Shorter, stiffer register than Gemini
 * but a stable fallback if the AI Studio key is unavailable.
 */
import { parseSrt, emitSrt, stripMarkup, type Cue } from '../srt.ts';
import { isWatermark, repairCues, wrap } from '../normalize.ts';

const ENDPOINT = 'https://translation.googleapis.com/language/translate/v2';

export async function translateBatch(apiKey: string, texts: string[], source = 'en', target = 'si'): Promise<string[]> {
  const r = await fetch(`${ENDPOINT}?key=${apiKey}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ q: texts, source, target, format: 'text' }),
  });
  if (!r.ok) throw new Error(`googleV3 ${r.status}`);
  const j = await r.json();
  const out: string[] = j?.data?.translations?.map((t: { translatedText: string }) => t.translatedText) ?? [];
  if (out.length !== texts.length) throw new Error(`googleV3 count mismatch: ${out.length}/${texts.length}`);
  return out;
}

/** Batched v3 translation with the same validator as the Gemini path. */
export async function translateSrt(apiKey: string, srtText: string, opts: { title: string }): Promise<string> {
  let cues: Cue[] = parseSrt(srtText);
  cues = cues.filter((c, i) => !isWatermark(stripMarkup(c.text), i, cues.length));
  cues = repairCues(cues);
  const batch = 128;   // v3 q-array limit safety
  const outTexts: string[] = [];
  for (let i = 0; i < cues.length; i += batch) {
    const slice = cues.slice(i, i + batch).map((c) => stripMarkup(c.text).replace(/\n/g, ' '));
    const t = await translateBatch(apiKey, slice);
    outTexts.push(...t);
  }
  const translated: Cue[] = cues.map((c, i) => ({ start: c.start, end: c.end, text: wrap(outTexts[i] ?? c.text, 40) }));
  return emitSrt(translated);
}
