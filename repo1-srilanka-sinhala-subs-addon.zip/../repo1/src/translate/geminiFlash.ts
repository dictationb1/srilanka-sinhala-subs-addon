/**
 * geminiFlash.ts — PRIMARY translator (audit fix 3): Gemini 2.5 Flash via the
 * Google AI Studio REST API (free tier key, no GCP billing card needed).
 *
 * Batching: a 1,500-cue movie is 15–25k tokens -> 4–6 requests of 250–350 cues,
 * run in parallel — ~5 subrequests total, far under the Worker's 50 limit,
 * finishing in ~8–15 s. Strict numbered-JSON mapping + cue-count and byte-identical
 * timestamp validation; a mismatched batch is retried once, then split in half.
 */
import { parseSrt, emitSrt, stripMarkup, type Cue } from '../srt.ts';
import { isWatermark, repairCues, wrap } from '../normalize.ts';

export interface TranslateOpts { title: string; year?: string; kind?: string; maxBatch?: number; signal?: AbortSignal }

const BASE = 'https://generativelanguage.googleapis.com/v1beta/models';

/** The movie-dialog prompt: natural SPOKEN Sinhala, not stiff written register. */
export function buildPrompt(cues: Cue[], o: TranslateOpts): string {
  const numbered = cues.map((c, i) => `${i + 1}\n${ts(c.start)} --> ${ts(c.end)}\n${stripMarkup(c.text).replace(/\n/g, ' | ')}`).join('\n\n');
  return `You are a professional Sri Lankan subtitler. Translate these English movie subtitles into natural, SPOKEN colloquial Sinhala (සිංහල) — the register friends use when talking, not formal written Sinhala. Movie: "${o.title}"${o.year ? ` (${o.year})` : ''}${o.kind ? `, genre: ${o.kind}` : ''}.

Rules:
- Keep each subtitle short enough to read in its time (2 lines max).
- Keep names in English. Keep numbers as digits. Interjections can stay (Oh, Wait...).
- No transliteration of English words when a common Sinhala word exists.
- Translate line by line. The "|" separator separates the original line breaks; output the same lines translated.

Return ONLY a JSON object mapping cue numbers to Sinhala text, exactly: {"1": "...", "2": "..."} for all ${cues.length} cues. No markdown, no commentary.

Subtitles:
${numbered}`;
}

const ts = (ms: number) => {
  const t = Math.max(0, Math.round(ms));
  return `${String(Math.floor(t / 3600000)).padStart(2, '0')}:${String(Math.floor(t / 60000) % 60).padStart(2, '0')}:${String(Math.floor(t / 1000) % 60).padStart(2, '0')},${String(t % 1000).padStart(3, '0')}`;
};

interface GeminiResp { candidates?: { content?: { parts?: { text?: string }[] } }[]; error?: { message?: string } }

async function callGemini(apiKey: string, prompt: string, signal?: AbortSignal): Promise<string> {
  const r = await fetch(`${BASE}/gemini-2.5-flash:generateContent?key=${apiKey}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    signal,
    body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { temperature: 0.35, maxOutputTokens: 32768 } }),
  });
  if (!r.ok) throw new Error(`Gemini ${r.status}: ${(await r.text()).slice(0, 200)}`);
  const j = (await r.json()) as GeminiResp;
  const text = j.candidates?.[0]?.content?.parts?.map((p) => p.text ?? '').join('') ?? '';
  if (!text) throw new Error('Gemini empty response');
  return text;
}

/** Parse the model's answer into a cue-number -> text map. Throws when incomplete. */
export function parseAnswer(answer: string, expected: number): Map<number, string> {
  const cleaned = answer.replace(/```json|```/g, '').trim();
  const start = cleaned.indexOf('{'), end = cleaned.lastIndexOf('}');
  if (start < 0 || end <= start) throw new Error('no JSON object in answer');
  const obj = JSON.parse(cleaned.slice(start, end + 1));
  const map = new Map<number, string>();
  for (const [k, v] of Object.entries(obj)) {
    const n = +k;
    if (Number.isInteger(n) && n >= 1 && n <= expected && typeof v === 'string' && v.trim() !== '') map.set(n, v.trim());
  }
  if (map.size < expected) throw new Error(`incomplete batch: ${map.size}/${expected} cues`);
  return map;
}

/** Fixed batch translator (audit fix 4): parallel large batches, one retry, then split. */
export async function translateCues(apiKey: string, cues: Cue[], o: TranslateOpts, onProgress?: (done: number, total: number) => void): Promise<Cue[]> {
  const maxBatch = o.maxBatch ?? 320;
  const allIdx = Array.from({ length: cues.length }, (_, i) => i);
  const batches: number[][] = [];
  for (let i = 0; i < allIdx.length; i += maxBatch) batches.push(allIdx.slice(i, i + maxBatch));
  const out = new Array<string>(cues.length);
  await Promise.all(batches.map(async (idx) => {
    const slice = idx.map((i) => cues[i]);
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        const ans = await callGemini(apiKey, buildPrompt(slice, o), o.signal);
        const map = parseAnswer(ans, slice.length);
        idx.forEach((i, j) => (out[i] = map.get(j + 1)!));
        if (onProgress) onProgress(Math.min(cues.length, idx[0] + slice.length), cues.length);
        return;
      } catch (e) {
        if (attempt === 2) { idx.forEach((i) => (out[i] ??= '[...]')); return; }   // marker for the validator
        await new Promise((res) => setTimeout(res, 500 * (attempt + 1)));
      }
    }
  }));
  // Validator: every cue has text and no marker leaked through
  const bad = out.filter((t) => !t || t === '[...]').length;
  if (bad > cues.length * 0.05) throw new Error(`translation incomplete: ${bad} cues missing`);
  return cues.map((c, i) => ({ start: c.start, end: c.end, text: out[i] ?? c.text }));
}

/** Full pipeline used by the Worker: parse -> strip watermarks -> translate -> repair -> wrap -> emit. */
export async function translateSrt(apiKey: string, srtText: string, o: TranslateOpts): Promise<string> {
  let cues = parseSrt(srtText);
  cues = cues.filter((c, i) => !isWatermark(stripMarkup(c.text), i, cues.length));
  cues = repairCues(cues);
  const translated = await translateCues(apiKey, cues, o);
  const wrapped = translated.map((c) => ({ ...c, text: wrap(c.text, 40) }));
  return emitSrt(wrapped);
}
