#!/usr/bin/env python3
"""
preindex.py — nightly pre-indexer (runs in GitHub Actions, never in the Worker).
Downloads zoom.lk / piratelk archives, unpacks ANY format (zip via Python, RAR via
`unrar p -inul`, 7z via `7z e -so`), converts to UTF-8 .srt and uploads to R2
under `preindex:<url>` keys that the Worker's /download route reads first.

Zero cost: GitHub Actions free tier + Cloudflare R2 free tier (10 GB).
Needs env: R2_ACCESS_KEY_ID, R2_SECRET_ACCESS_KEY, R2_ENDPOINT, R2_BUCKET.
Uses only stdlib + the sibling srt_tools.py (no pip installs).
"""
from __future__ import annotations

import io
import json
import os
import re
import subprocess
import sys
import urllib.request
import zipfile

sys.path.insert(0, os.path.dirname(__file__))
import srt_tools as st  # noqa: E402

UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"}


def http_get(url: str, timeout: int = 30) -> bytes:
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read(MAX := 8 * 1024 * 1024)


def extract_any(data: bytes) -> bytes:
    """zip in-Python; RAR/7z via CLI (available on GH Actions runners)."""
    if data[:2] == b"\x1f\x8b":
        import gzip
        return gzip.decompress(data)
    if data[:4] == b"PK\x03\x04":
        b, _ = st.extract_archive(data)
        return b
    if data[:7] == b"Rar!\x1a\x07\x00" or data[:8] == b"Rar!\x1a\x07\x01\x00":
        p = subprocess.run(["unrar", "p", "-inul", "-"], input=data, capture_output=True)
        if p.returncode != 0 and p.stdout[:4] != b"PK\x03\x04" and b"-->" not in p.stdout:
            raise RuntimeError("unrar failed")
        return p.stdout
    if data[:6] == b"7z\xbc\xaf\x27\x1c":
        p = subprocess.run(["7z", "e", "-so", "-"], input=data, capture_output=True)
        if b"-->" not in p.stdout:
            raise RuntimeError("7z failed")
        return p.stdout
    return data


def to_srt(data: bytes) -> str:
    text = st.decode(data)
    cues = st.parse(text)
    if not cues:
        raise RuntimeError("no cues")
    cues = st.strip_watermarks(cues)
    cues = st.repair_cues(cues)
    return st.emit(cues)


def r2_put(key: str, body: str) -> None:
    """Minimal S3 PUT (single-shot, no dependency): SigV4 is required by R2, so
    this helper shells out to wrangler instead when credentials are absent."""
    token = os.environ.get("R2_ACCESS_KEY_ID")
    if not token:
        print(f"[dry-run] would put {key} ({len(body)} bytes)")
        return
    # wrangler r2 object put <bucket>/<key> --file <tmp>
    with tempfile(key, body) as path:
        subprocess.run(
            ["npx", "wrangler", "r2", "object", "put", f"{os.environ['R2_BUCKET']}/{key}", "--file", path],
            check=False,
        )


import contextlib


@contextlib.contextmanager
def tempfile(key: str, body: str):
    import pathlib
    import tempfile as tf

    d = tf.mkdtemp()
    p = pathlib.Path(d) / "body.srt"
    p.write_text(body, encoding="utf-8")
    yield str(p)


def main() -> None:
    # Trending posts: zoom.lk homepage slugs (robots-allowed; /dlm_uploads/ never touched)
    seen: set[str] = set()
    posts: list[str] = []
    for url in ("https://zoom.lk/",):
        try:
            html = http_get(url).decode("utf-8", errors="replace")
            posts += [m for m in re.findall(r"https://zoom\.lk/[a-z0-9%.-]+/", html)]
        except Exception as e:
            print("skip", url, e)
    for post in posts[:20]:
        if post in seen or "sub-download" in post:
            continue
        seen.add(post)
        try:
            html = http_get(post).decode("utf-8", errors="replace")
            ids = re.findall(r"href=['\"](https://zoom\.lk/sub-download/\d+)['\"]", html)
            for dl in ids[:2]:
                data = http_get(dl)
                if data[:4] == b"PK\x03\x04" or b"-->" in extract_any(data)[:4000]:
                    srt = to_srt(extract_any(data))
                    r2_put(f"preindex:{dl}", srt)
                    print("preindexed", dl, len(srt), "bytes")
        except Exception as e:
            print("skip", post, e)


if __name__ == "__main__":
    main()
