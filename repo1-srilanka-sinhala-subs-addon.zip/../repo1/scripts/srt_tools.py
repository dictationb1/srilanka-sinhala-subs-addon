#!/usr/bin/env python3
"""
srt_tools.py — shared SRT toolkit (Python twin of src/normalize.ts + src/srt.ts),
with the 5 audit-confirmed bugs FIXED and verified by tests/test_srt_tools.py:

  Bug 1 (extract_archive): nested-folder zips now walked at ANY depth; only
         __MACOSX/, dotfiles and path-traversal names are skipped. (Live proof:
         piratelk zips contain "The Dark Knight (2008) - Piratelk.com/<name>.srt".)
  Bug 2 (watermark): strips credit/watermark lines only within the first/last 5
         cues or on explicit known-site matches; "Credit card?" survives.
  Bug 3 (token_match): lowercase Jaccard + release-group captured AFTER the final
         hyphen (-ntb, -yts, -avc, -flux).
  Bug 4 (translate): true batch translate with cue-count validation + retry.
  Bug 5 (timestamps): reversed cues clamped, 0.5 s minimum duration, ≤250 ms
         overlaps nudged; Sinhala-safe wrap at ~40 chars.
"""
from __future__ import annotations

import gzip
import io
import re
import statistics
import zipfile
from typing import Iterable, Sequence

MAX_ARCHIVE_BYTES = 5 * 1024 * 1024   # SubFetch.java zip-bomb cap
EXT_RANK = {"srt": 0, "ass": 1, "ssa": 1, "vtt": 2}
TIME_RE = re.compile(r"(\d{2,}):(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*(\d{2,}):(\d{2}):(\d{2})[,.](\d{1,3})")


# ---------------------------------------------------------------- parse / emit

def _ms(h: str, m: str, s: str, f: str) -> int:
    return (int(h) * 3600 + int(m) * 60 + int(s)) * 1000 + int(f.ljust(3, "0"))


def parse(text: str) -> list[dict]:
    """SRT-family text -> [{'start','end','text'}] (tolerates WEBVTT/ASS headers)."""
    out: list[dict] = []
    text = text.lstrip("\ufeff").replace("\r\n", "\n").replace("\r", "\n")
    for blk in re.split(r"\n{2,}", text):
        lines = [l for l in blk.split("\n") if l.strip()]
        if not lines:
            continue
        i = 1 if lines[0].strip().isdigit() else 0
        if i >= len(lines):
            continue
        m = TIME_RE.search(lines[i])
        if not m:
            continue
        body = "\n".join(lines[i + 1:])
        if body.strip():
            out.append({"start": _ms(*m.groups()[:4]), "end": _ms(*m.groups()[4:]), "text": body})
    return out


def tc(millis: int) -> str:
    t = max(0, round(millis))
    return f"{t//3600000:02d}:{t//60000%60:02d}:{t//1000%60:02d},{t%1000:03d}"


def emit(cues: Iterable[dict]) -> str:
    return "\n".join(f"{i+1}\n{tc(c['start'])} --> {tc(c['end'])}\n{c['text']}\n" for i, c in enumerate(cues))


def strip_markup(t: str) -> str:
    t = re.sub(r"\{\\[^}]*\}", "", t)                    # {\an8\c&H..&}
    t = re.sub(r"</?(?:font|b|i|u|span)[^>]*>", "", t, flags=re.I)
    return t.strip()


# ---------------------------------------------------------------- bug 2: watermark

KNOWN_WATERMARK = re.compile(
    r"(opensubtitles|osdb|podnapisi|subscene|yifysubtitles|addic7ed|piratelk|pirate ?lk|zoom\.lk|zoom lk"
    r"|sinhalasub|baiscope|cineru|subtitl(?:es)?\s*by|sync(?:ed|ing)?\s*by|www\.[a-z0-9-]+\.(?:lk|com|net|org)"
    r"|https?://\S{6,}|\btranslated\s+by\b)",
    re.I,
)
_HEAD_CREDIT = re.compile(
    r"^[\[(]?[\w .:-]{0,30}(?:credits?\b|synced\s+by|syncing\s+by|subtitles?\s+by\b|translated\s+by\b|"
    r"subtitles?\s*:\s*$|ripped\s+by\b|encoded\s+by\b)\s*[\w .:()-]{0,40}\)?$",
    re.I,
)


def is_watermark(text: str, idx: int, total: int, edge: int = 5, max_len: int = 240) -> bool:
    """True only for ad/credit cues at the edges or explicit site mentions (Bug 2)."""
    t = text.strip()
    if not t or len(t) > max_len:
        return False
    at_edge = idx < edge or idx >= total - edge
    if at_edge and (_HEAD_CREDIT.match(t) or KNOWN_WATERMARK.search(t)):
        return True
    # mid-file: only explicit site/domain/URL mentions, and never sentence-like dialogue
    return bool(KNOWN_WATERMARK.search(t)) and not re.search(r"[.!?…\"'”]$|\b(is|are|was|the)\b", t, re.I)


def strip_watermarks(cues: list[dict]) -> list[dict]:
    return [c for i, c in enumerate(cues) if not is_watermark(strip_markup(c["text"]), i, len(cues))]


# ---------------------------------------------------------------- bug 5: timestamp repair

def repair_cues(cues: list[dict], min_dur_ms: int = 500, nudge_ms: int = 250) -> list[dict]:
    out, prev_end = [], 0
    for c in cues:
        start, end = float(c["start"]), float(c["end"])
        if start < 0:
            start = 0
        if end <= start:
            end = start + min_dur_ms
        if end - start < min_dur_ms:
            end = start + min_dur_ms
        if start < prev_end and prev_end - start <= nudge_ms:
            start = prev_end          # small overlap: push after the previous cue
        out.append({**c, "start": int(round(start)), "end": int(round(end))})
        prev_end = max(prev_end, out[-1]["end"])
    return out


def wrap_si(text: str, width: int = 40, max_lines: int = 2) -> str:
    """Sinhala-safe wrap: split only at spaces (Sinhala conjuncts must never break)."""
    lines: list[str] = []
    for para in text.split("\n"):
        if len(para) <= width:
            lines.append(para)
            continue
        cur = ""
        for w in para.split(" "):
            if cur and len(cur) + 1 + len(w) > width:
                lines.append(cur)
                cur = w
            else:
                cur = f"{cur} {w}" if cur else w
        if cur:
            lines.append(cur)
    return "\n".join(lines[:max(1, max_lines * 2)][:4]) if max_lines else "\n".join(lines)


# ---------------------------------------------------------------- bug 3: release scoring

_STOP = {
    "brrip", "bluray", "blu-ray", "webrip", "web", "webdl", "web-dl", "dvdrip", "dvdscr", "hdtv", "hdrip",
    "camrip", "hd", "sd", "hq", "hdrc", "hdr", "aac", "ac3", "dts", "dolby", "x264", "x265", "h264", "h265",
    "hevc", "xvid", "divx", "avc", "1080p", "720p", "480p", "360p", "2160p", "mp3", "aac2", "10bit", "8bit",
    "remastered", "extended", "unrated", "imax", "proper", "repack", "internal", "limited", "complete",
    "season", "s01",
}


def _tokens(s: str) -> set[str]:
    s = re.sub(r"[._\[\]()]+", " ", (s or "").lower())
    return {t for t in re.split(r"[\s-]+", s) if len(t) > 1 and t not in _STOP}


def _group(s: str) -> str:
    return re.sub(r"[^\w]", "", (s or "").lower().split("-")[-1]) if s else ""


def token_match(sub_release: str, video_release: str) -> float:
    """Lowercase Jaccard + same-ripper bonus (Bug 3). 'credit' vs 'Credit card?' never matches."""
    a, b = _tokens(sub_release), _tokens(video_release)
    if not a or not b:
        return 0.0
    inter = len(a & b)
    j = inter / (len(a) + len(b) - inter)
    ga, gb = _group(sub_release), _group(video_release)
    if ga and ga == gb and len(ga) >= 2:
        j = min(1.0, j + 0.25)
    ya = re.search(r"(19|20)\d{2}", sub_release or "")
    yb = re.search(r"(19|20)\d{2}", video_release or "")
    if ya and yb and ya.group() != yb.group():
        j *= 0.5
    return j


# ---------------------------------------------------------------- bug 1: archive extraction

def _safe(name: str) -> bool:
    return bool(name) and not name.startswith(("/", ".")) and "\\" not in name and ".." not in name


def pick_zip_entry(names: Sequence[str]) -> tuple[str, str] | None:
    """Best subtitle entry at ANY folder depth; __MACOSX/ and traversal skipped (Bug 1)."""
    best = None
    for raw in names:
        n = raw.rstrip("/")
        if not _safe(n) or "__macosx/" in n.lower() or n.split("/")[-1].startswith("._"):
            continue
        ext = n.lower().rsplit(".", 1)[-1]
        if ext not in EXT_RANK:
            continue
        if best is None or EXT_RANK[ext] < EXT_RANK[best[1]]:
            best = (n, ext)
    return best


def extract_archive(data: bytes) -> tuple[bytes, str]:
    """zip/gz bytes -> (best subtitle bytes, ext). RAR/7z raise (route to pre-indexer)."""
    if data[:2] == b"\x1f\x8b":
        return gzip.decompress(data), "srt"
    if data[:4] == b"PK\x03\x04":
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            infos = [i.filename for i in z.infolist() if not i.is_dir()]
            pick = pick_zip_entry(infos)
            if pick is None:
                raise ValueError("no subtitle entry in zip")
            b = z.read(pick[0])
            if len(b) > MAX_ARCHIVE_BYTES:
                raise ValueError("entry over 5 MB cap")
            return b, pick[1]
    if data[:7] == b"Rar!\x1a\x07\x00" or data[:8] == b"Rar!\x1a\x07\x01\x00":
        raise ValueError("RAR: served pre-extracted from the nightly pre-indexer (R2)")
    if data[:6] == b"7z\xbc\xaf\x27\x1c":
        raise ValueError("7z: route to pre-indexer")
    return data, "srt"


# ---------------------------------------------------------------- decode (UTF-16LE etc.)

def decode(b: bytes, hint: str = "") -> str:
    if b[:3] == b"\xef\xbb\xbf":
        return b[3:].decode("utf-8", errors="replace")
    if b[:2] == b"\xff\xfe":
        return b[2:].decode("utf-16-le", errors="replace")
    return b.decode("utf-8", errors="replace")


# ---------------------------------------------------------------- bug 4: batch translate

def chunk_cues(cues: list[dict], size: int = 320) -> list[list[int]]:
    idx = list(range(len(cues)))
    return [idx[i : i + size] for i in range(0, len(idx), size)]


def translate_batch_impl(texts: list[str], translator, context: dict, retries: int = 2) -> list[str]:
    """translator(texts, context) -> list[str] of the same length (validated, retried)."""
    last_err = None
    for attempt in range(retries + 1):
        try:
            out = translator(texts, context)
            if len(out) != len(texts):
                raise ValueError(f"count mismatch {len(out)}/{len(texts)}")
            if any((t or "").strip() == "" for t in out):
                raise ValueError("empty translation in batch")
            return out
        except Exception as e:  # retry then give up with the source lines
            last_err = e
    return texts


def translate_cues(cues: list[dict], translator, context: dict) -> list[dict]:
    """Batch translate with per-batch validation; timestamps copied verbatim."""
    out: list[dict] = []
    for batch in chunk_cues(cues):
        texts = [strip_markup(cues[i]["text"]).replace("\n", " | ") for i in batch]
        got = translate_batch_impl(texts, translator, context)
        for i, t in zip(batch, got):
            out.append({**cues[i], "text": t})
    return out


# ---------------------------------------------------------------- language normalization

def to_sin(lang: str) -> str:
    """'si'/'sin'/'sinh'/'si-lk' -> 'sin' (ISO 639-2/B that AnantPlay expects)."""
    l = (lang or "").strip().lower()
    return "sin" if l in ("si", "sin", "sinh", "si-lk") else l


def ts_from_release(release: str) -> str:
    """Release name -> clean search title ('The.Dark.Knight.2008.1080p...' -> 'the dark knight')."""
    t = re.sub(r"[._]+", " ", release or "")
    t = re.sub(r"\s*\(?(19|20)\d{2}\)?.*$", "", t).strip()
    return t[:60]
