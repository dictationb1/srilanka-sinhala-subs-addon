# Sri Lanka Sinhala Subtitles — Stremio Addon (Cloudflare Worker)

**සිංහල උපසිරැසි ඇඩෝනය** — piratelk.com + zoom.lk + OpenSubtitles ඒකාබද්ධ කර, සිංහල උපසිරැසි නැති විට ඉංග්‍රීසි උපසිරැසි Gemini මගින් සිංහලට පරිවර්තනය කරයි.

A production-ready, zero-cost Cloudflare Worker that serves Sinhala subtitles over the Stremio addon protocol (`/subtitles/{type}/{id}.json`, `/download/{token}.srt`). Pure TypeScript — **no Python/Rust/unrar binaries in the Worker** (Cloudflare free tier: 10 ms CPU, 50 subrequests — all extraction is fflate pure-JS, translation runs in `ctx.waitUntil`, RAR is pre-extracted nightly by GitHub Actions into R2).

---

## 5-minute setup (සම්පූර්ණ නොමිලේ)

### 1 · Cloudflare Worker + KV (free)

```bash
npm install -g wrangler@latest
wrangler login
wrangler kv namespace create SUBS_INDEX      # copy the id into wrangler.toml
# optional (KV-only fallback works without it):
wrangler r2 bucket create subs-bucket
```

Edit `wrangler.toml`: replace `REPLACE_WITH_KV_ID` with the printed id.

### 2 · Free Gemini API key (Google AI Studio — **no credit card**)

1. Open <https://aistudio.google.com/apikey> → **Create API key**.
2. `wrangler secret put GEMINI_API_KEY` → paste it.

Optional second provider: `wrangler secret put GOOGLE_TRANSLATE_KEY` (Cloud Translation v3; needs GCP), and set `[vars] TRANSLATOR_PROVIDER = "google_v3"` in `wrangler.toml`.

### 3 · Deploy and test

```bash
wrangler deploy
# Stremio protocol check:
curl -s https://<your-worker>.workers.dev/manifest.json
curl -s "https://<your-worker>.workers.dev/subtitles/movie/tt0468569.json?videoRelease=The%20Dark%20Knight%202008"
curl -s "https://<your-worker>.workers.dev/health"
```

Install into Stremio (or point AnantPlay's fork at it — see the sibling `anantplay-sinhala` repo): `https://<your-worker>.workers.dev/manifest.json`.

### 4 · Nightly pre-indexer (only if you keep RAR-era archives)

GitHub → **Settings → Secrets → Actions**: add `CLOUDFLARE_API_TOKEN` (deploy), and optionally `R2_ACCESS_KEY_ID`, `R2_SECRET_ACCESS_KEY`, `R2_ENDPOINT` (pre-indexer). The included `.github/workflows/ci-deploy.yml` runs tests on every push, deploys on main, and pre-extracts trending zoom.lk/piratelk archives into R2 at 19:17 UTC nightly.

---

## Architecture (audit-corrected)

| Layer | What runs where | Why |
| --- | --- | --- |
| **Search** | Worker fetches OpenSubtitles `sin`, piratelk WP-JSON (bypasses its Cloudflare search wall — live-verified), zoom.lk `?s=` pages | 3–5 subrequests |
| **Extraction** | fflate pure-JS zip/gzip, nested-folder aware, UTF-16LE decode | ~1 ms per 100 KB, no binaries |
| **RAR** | never in the Worker; GitHub Actions nightly `scripts/preindex.py` unpacks via `unrar p -inul` into R2 | Worker CPU limit |
| **Translation** | Gemini 2.5 Flash, 4–6 batches × 250–350 cues, parallel `Promise.all`, strict numbered-JSON + count validation | ≤6 subrequests, ~8–15 s, natural spoken Sinhala |
| **Sync** | pure-TS cue-start cross-correlation (offset + 23.976↔25 fps) + the app's own `SubSync`/`SpeechMeter` on-device audio sync | <3 ms CPU |
| **Cache** | R2 permanent (`sub:<sha1>`), KV fallback, KV job lock | repeated downloads are free |

### The `si` ↔ `sin` contract

AnantPlay filters Stremio rows with an exact `osCode(lang).equals(code)` match (`Subs.java:71`), so **every row this addon emits carries `"lang": "sin"`** (ISO 639-2/B), and the fork normalizes `si`/`sinh`/`si-lk` → `sin` on its side too. Zero rows dropped, zero mislabeled.

### 202 translation protocol

`GET /download/<token>.srt` replies `202` + `Retry-After: 10` while the Gemini job runs in `ctx.waitUntil`; the fork's `SubFetch` treats the small body as a retry signal and retries once after 10 s with a Toast ("Translating to Sinhala…"); standard Stremio clients poll until 200.

## Tests

```bash
node --test tests/*.ts      # 14/14 PASS (normalizer on REAL piratelk/zoom.lk archives, scorer, aligner, validator, si/sin)
python3 -m pytest tests/ -q # 9/9 PASS (the 5 audit bug fixes)
```

Fixtures are the actual archives downloaded from both sites on 2026-11-20 (nested-folder zip with UTF-16LE variant; flat zip with 1513 Sinhala cues) — the exact bytes real users get.

## Sources & robots.txt (re-audited 2026-11-20)

| Site | Status | Method | robots.txt |
| --- | --- | --- | --- |
| piratelk.com | ✅ open | WP-JSON API (Cloudflare-free) + DLM zip | fully open (`Disallow:`) |
| zoom.lk | ✅ open | `?s=` search + `/sub-download/<id>` zip | only `/dlm_uploads/` disallowed — **never touched** |
| sinhalasub.lk | ❌ excluded v1 | login-gated `/links/<token>/` interstitials | open, but auth wall |
| OpenSubtitles | ✅ | legacy REST `sublanguageid-sin` | API by design |
| SubDL | ⏸ optional | API key | limits UNVERIFIED — off by default |

## License & conduct

MIT. The vendored `fflate` carries its own MIT license (`vendor/LICENSE-fflate.txt`). Scrapers stay on robots.txt-allowed routes with a browser User-Agent, request at most a few pages per lookup, and cache aggressively — please keep them that way if you fork this.
